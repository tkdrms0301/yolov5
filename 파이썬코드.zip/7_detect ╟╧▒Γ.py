!python detect.py --source F:\\yolo\\images\\test\\hard_hat_workers3.png --project F:\\yolo\\yolov5\\runs\\detect\\test --name test --weights F:\\yolo\\yolov5\\runs\\train\\exp5\\weights\\best.pt --conf 0.25

!python detect.py --source [이미지 파일 또는 동영상 파일 경로] --project [저장할 폴더 경로] --name [저장하는 폴더 경로 1씩 증가하며 생성됨] --weights [가중치 파일 경로] --conf 0.25